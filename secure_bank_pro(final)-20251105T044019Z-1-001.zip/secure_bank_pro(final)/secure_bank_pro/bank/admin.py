from django.contrib import admin
from .models import (
    BankEmployee, Customer, KYC, ATMCard,
    WithdrawRequest, DepositRequest, TransferRequest, FixedDeposit
)
#Username(sanjayababu,chandhan)
#Password(2001,2002)
class BankEmployeeAdmin(admin.ModelAdmin):
    list_display = ('name', 'employee_id', 'email', 'role')
    search_fields = ('name', 'employee_id', 'email', 'role')

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'account_number', 'account_type', 'balance', 'kyc_verified')
    search_fields = ('full_name', 'email', 'phone', 'account_number')
    list_filter = ('account_type', 'kyc_verified')

class KYCAdmin(admin.ModelAdmin):
    list_display = ('customer', 'aadhaar_number', 'pan_number', 'verified')
    search_fields = ('customer__full_name', 'aadhaar_number', 'pan_number')
    list_filter = ('verified',)

class ATMCardAdmin(admin.ModelAdmin):
    list_display = ('customer', 'card_number', 'is_active')
    search_fields = ('customer__full_name', 'card_number')
    list_filter = ('is_active',)

class WithdrawRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'amount', 'created_at', 'status')
    list_filter = ('status', 'created_at')

class DepositRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'amount', 'created_at', 'status')
    list_filter = ('status', 'created_at')



class TransferRequestAdmin(admin.ModelAdmin):
    list_display = ('sender', 'receiver_account_number', 'amount', 'status', 'timestamp')
    search_fields = ('sender__full_name', 'receiver_account_number')
    list_filter = ('status', 'timestamp')

class FixedDepositAdmin(admin.ModelAdmin):
    list_display = ('customer', 'amount', 'interest_rate', 'duration_months', 'start_date', 'status')
    search_fields = ('customer__full_name',)
    list_filter = ('status', 'start_date')

# Register all models with their respective admins
admin.site.register(BankEmployee, BankEmployeeAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(KYC, KYCAdmin)
admin.site.register(ATMCard, ATMCardAdmin)
admin.site.register(TransferRequest, TransferRequestAdmin)
admin.site.register(FixedDeposit, FixedDepositAdmin)
admin.site.register(WithdrawRequest, WithdrawRequestAdmin)
admin.site.register(DepositRequest, DepositRequestAdmin)
