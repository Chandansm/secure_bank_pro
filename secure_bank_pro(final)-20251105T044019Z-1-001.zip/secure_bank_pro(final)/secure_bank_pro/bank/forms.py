from django import forms
from .models import Customer, KYC, ATMCard, WithdrawRequest, DepositRequest
from django.contrib.auth.forms import AuthenticationForm
from django.core.exceptions import ValidationError
import re

class CustomerRegistrationForm(forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'input-field'}),
        label="Password"
    )

    class Meta:
        model = Customer
        fields = ['full_name', 'email', 'phone', 'account_type', 'password']
        widgets = {
            'full_name': forms.TextInput(attrs={'class': 'input-field'}),
            'email': forms.EmailInput(attrs={'class': 'input-field'}),
            'phone': forms.TextInput(attrs={'class': 'input-field'}),
            'account_type': forms.Select(attrs={'class': 'input-field'}),
        }

    def clean_full_name(self):
        full_name = self.cleaned_data.get('full_name')
        if not full_name.replace(' ', '').isalpha():
            raise forms.ValidationError("Full Name must contain only letters and spaces.")
        return full_name

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if not email.endswith('@gmail.com'):
            raise forms.ValidationError("Email must end with @gmail.com.")
        return email

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if not re.match(r'^[6-9]\d{9}$', phone):
            raise forms.ValidationError("Phone number must start with 6, 7, 8, or 9 and must be exactly 10 digits.")
        return phone

    def clean_password(self):
        password = self.cleaned_data.get('password')
        if len(password) < 6:
            raise forms.ValidationError("Password must be at least 6 characters long.")
        return password

class KYCForm(forms.ModelForm):
    class Meta:
        model = KYC
        fields = ['aadhaar_number', 'pan_number', 'document']
        widgets = {
            'aadhaar_number': forms.TextInput(attrs={'placeholder': 'Enter Aadhaar Number'}),
            'pan_number': forms.TextInput(attrs={'placeholder': 'Enter PAN Number'}),
        }

    # Custom validation for Aadhaar Number (12 digits, no letters)
    def clean_aadhaar_number(self):
        aadhaar_number = self.cleaned_data.get('aadhaar_number')
        if len(aadhaar_number) != 12 or not aadhaar_number.isdigit():
            raise ValidationError("Aadhaar Number must be 12 digits long and contain only numbers.")
        return aadhaar_number

    # Custom validation for PAN Number (5 letters, 4 digits, 1 letter)
    def clean_pan_number(self):
        pan_number = self.cleaned_data.get('pan_number')
        pan_regex = r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$'  # Regex pattern for PAN validation
        if not re.match(pan_regex, pan_number):
            raise ValidationError("PAN Number must follow the pattern: 5 letters, 4 digits, 1 letter (e.g., ABCDE1234F).")
        return pan_number
    
    
class OTPVerificationForm(forms.Form):
    otp = forms.CharField(max_length=6, label="Enter OTP")

class SetPINForm(forms.Form):
    new_pin = forms.CharField(max_length=6, widget=forms.PasswordInput)
    confirm_pin = forms.CharField(max_length=6, widget=forms.PasswordInput)

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('new_pin') != cleaned_data.get('confirm_pin'):
            raise forms.ValidationError("PINs do not match.")
        return cleaned_data

        
class EmployeeLoginForm(AuthenticationForm):
    username = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'placeholder': 'Employee ID'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))        
    



class ATMSetupForm(forms.Form):
    card_number = forms.CharField(
        max_length=16,
        label="ATM Card Number",
        widget=forms.TextInput(attrs={
            'class': 'w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500',
            'placeholder': 'Enter your 16-digit card number'
        })
    )
    otp = forms.CharField(
        max_length=6,
        label="OTP",
        widget=forms.TextInput(attrs={
            'class': 'w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500',
            'placeholder': 'Enter the OTP sent to your email'
        })
    )
    pin = forms.CharField(
        max_length=4,
        label="Set ATM PIN",
        widget=forms.PasswordInput(attrs={
            'class': 'w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500',
            'placeholder': '4-digit PIN'
        })
    )

class WithdrawRequestForm(forms.ModelForm):
    class Meta:
        model = WithdrawRequest
        fields = ['amount']
        widgets = {
            'amount': forms.NumberInput(attrs={
                'class': 'w-full p-2 border border-gray-300 rounded',
                'placeholder': 'Enter amount to withdraw'
            }),
        }

class DepositRequestForm(forms.ModelForm):
    class Meta:
        model = DepositRequest
        fields = ['amount']
        widgets = {
            'amount': forms.NumberInput(attrs={
                'class': 'w-full p-2 border border-gray-300 rounded',
                'placeholder': 'Enter amount to deposit'
            }),
        }    