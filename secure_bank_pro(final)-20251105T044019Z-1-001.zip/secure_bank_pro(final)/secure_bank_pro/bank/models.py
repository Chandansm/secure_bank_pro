from django.db import models
import datetime
from django.utils import timezone
import random
from datetime import timedelta


ACCOUNT_TYPES = [
    ('SAVINGS', 'Savings Account'),
    ('CURRENT', 'Current Account'),
]

class BankManager(models.Model):
    name = models.CharField(max_length=100)
    manager_id = models.CharField(max_length=50, unique=True)
    email = models.EmailField()
    password = models.CharField(max_length=128)  # Again, we can later hash or migrate to Django auth

    def __str__(self):
        return self.name 

class BankEmployee(models.Model):
    EMPLOYEE_ROLES = [
        ('cashier', 'Cashier'),
        ('kyc_officer', 'KYC Officer'),
    ]

    name = models.CharField(max_length=100)
    employee_id = models.CharField(max_length=50, unique=True)
    email = models.EmailField()
    password = models.CharField(max_length=128)  # simple, replace with auth in future
    role = models.CharField(max_length=20, choices=EMPLOYEE_ROLES, default='cashier')

    def __str__(self):
        return f"{self.name} ({self.get_role_display()})"

   
class Customer(models.Model):
    full_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15, unique=True)
    account_number = models.CharField(max_length=12, unique=True)
    account_type = models.CharField(max_length=10, choices=ACCOUNT_TYPES)
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0.0)
    kyc_verified = models.BooleanField(default=False)
    
    # Password field that should be non-nullable
    password = models.CharField(max_length=255, null=False, blank=False)

    def __str__(self):
        return f"{self.full_name} - {self.account_number}"


class KYC(models.Model):
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    aadhaar_number = models.CharField(max_length=12)
    pan_number = models.CharField(max_length=10)
    document = models.FileField(upload_to='kyc_docs/')
    verified = models.BooleanField(default=False)

    def __str__(self):
        return f"KYC - {self.customer.full_name}"

class ATMCard(models.Model):
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    card_number = models.CharField(max_length=16, unique=True)
    pin = models.CharField(max_length=6, blank=True)
    is_active = models.BooleanField(default=False)

    # OTP related fields
    otp = models.CharField(max_length=6, blank=True, null=True)
    otp_created_at = models.DateTimeField(blank=True, null=True)

    # ✅ Add these new fields
    valid_from = models.DateField(blank=True, null=True)
    valid_thru = models.DateField(blank=True, null=True)

    def __str__(self):
        return f"ATM - {self.customer.full_name}"

    def generate_otp(self):
        self.otp = str(random.randint(100000, 999999))
        self.otp_created_at = timezone.now()
        self.save()

# Additional models will come later: FD, WithdrawRequest, DepositRequest, TransferRequest

class WithdrawRequest(models.Model):
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(default=timezone.now)
    status_choices = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=status_choices, default='pending')
    remarks = models.TextField(blank=True, null=True)  # Employee remarks

    def __str__(self):
        return f"Withdraw Request - {self.customer.full_name} - {self.amount}"

class DepositRequest(models.Model):
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(default=timezone.now)
    status_choices = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=status_choices, default='pending')
    remarks = models.TextField(blank=True, null=True)  # Employee remarks

    def __str__(self):
        return f"Deposit Request - {self.customer.full_name} - {self.amount}"


class TransferRequest(models.Model):
    sender = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='sent_transfers')
    receiver_account_number = models.CharField(max_length=20)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(
        max_length=20,
        choices=[('Pending', 'Pending'), ('Approved', 'Approved'), ('Rejected', 'Rejected')],
        default='Pending'
    )
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender.full_name} → {self.receiver_account_number} - ₹{self.amount} - {self.status}"
    

class FixedDeposit(models.Model):
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    interest_rate = models.FloatField(default=5.5)  # Default interest rate
    duration_months = models.IntegerField()
    start_date = models.DateField(auto_now_add=True)
    status = models.CharField(
        max_length=20,
        choices=[('Active', 'Active'), ('Matured', 'Matured')],
        default='Active'
    )

    @property
    def maturity_amount(self):
        """Simple interest calculation"""
        duration_years = self.duration_months / 12
        return self.amount + (self.amount * self.interest_rate * duration_years / 100)

    @property
    def maturity_date(self):
        return self.start_date + datetime.timedelta(days=30 * self.duration_months)

    def __str__(self):
        return f"{self.customer.full_name} - ₹{self.amount} - {self.status}"
