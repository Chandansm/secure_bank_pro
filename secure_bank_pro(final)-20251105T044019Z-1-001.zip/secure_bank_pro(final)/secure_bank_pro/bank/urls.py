from django.shortcuts import render
from django.urls import path
from . import views
from .views import download_virtual_card


urlpatterns = [
    path('', views.home, name='home'),  # Homepage
    path('register/', views.register_customer, name='register_customer'),
    path('success/<str:account_number>/', views.registration_success, name='registration_success'),

    # KYC
    path('kyc/<str:account_number>/', views.kyc_submission, name='kyc_submission'),
    path('kyc_success/', views.kyc_success, name='kyc_success'),
    path('verify-kyc/<int:kyc_id>/', views.verify_kyc, name='verify_kyc'),
    path('reject-kyc/<int:kyc_id>/', views.reject_kyc, name='reject_kyc'),
    path('employee/kyc-requests/', views.kyc_requests, name='kyc_requests'),  # ✅ New view to list pending KYCs

    # ATM Setup & OTP
    path('atm-setup/<str:account_number>/', views.atm_setup, name='atm_setup'),
    path('atm-setup/success/', views.kyc_success, name='atm_success'),  # Reuse template
    path('atm/set-pin/<str:account_number>/', views.set_atm_pin, name='set_atm_pin'),
    path('atm/verify-otp/<str:account_number>/', views.verify_otp, name='verify_otp'),

    # Customer Login/Logout/Dashboard
    path('customer/login/', views.customer_login, name='customer_login'),
    path('customer/dashboard/', views.customer_dashboard, name='customer_dashboard'),
    path('customer/logout/', views.customer_logout, name='customer_logout'),
    
    # Customer Deposit and withdraw urls
    path('withdraw_request.html/', views.withdraw_request, name='withdraw_request'),
    path('deposit_request.html/', views.deposit_request, name='deposit_request'),
    
    # Customer Virtual Atm card download
    path('download-virtual-card/<str:account_number>/', download_virtual_card, name='download_virtual_card'),


   # Employee Login/Logout/Dashboard
    path('employee/login/', views.employee_login, name='employee_login'),
    path('employee/dashboard/', views.employee_dashboard, name='employee_dashboard'),
    path('employee/cashier_dashboard/', views.cashier_dashboard, name='cashier_dashboard'),
    path('employee/logout/', views.employee_logout, name='employee_logout'),

  
     # Manager login
    path('manager/login/', views.manager_login, name='manager_login'),

    # Manager dashboard
    path('manager/dashboard/', views.manager_dashboard, name='manager_dashboard'),

    # Manager logout (add the logout view in your views.py if not already defined)
    path('manager/logout/', views.manager_logout, name='manager_logout'),

    # Register new employee (add this view in your views.py if not already defined)
    path('manager/register-employee/', views.register_employee, name='register_employee'),
    
    
    # Approve or Reject withdraw or request
    path('approve_withdraw_request/<int:request_id>/', views.approve_withdraw_request, name='approve_withdraw_request'),
    path('reject_withdraw_request/<int:request_id>/', views.reject_withdraw_request, name='reject_withdraw_request'),
    path('approve_deposit_request/<int:request_id>/', views.approve_deposit_request, name='approve_deposit_request'),
    path('reject_deposit_request/<int:request_id>/', views.reject_deposit_request, name='reject_deposit_request'),
]

