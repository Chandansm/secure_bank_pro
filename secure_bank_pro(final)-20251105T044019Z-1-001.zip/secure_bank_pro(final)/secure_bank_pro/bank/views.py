from multiprocessing import context
from django.shortcuts import render, redirect, get_object_or_404
from .forms import CustomerRegistrationForm, KYCForm, ATMSetupForm, EmployeeLoginForm, WithdrawRequestForm, DepositRequestForm
from .models import Customer, KYC, ATMCard, WithdrawRequest, DepositRequest, TransferRequest, BankEmployee, BankManager
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
import random
import logging
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.mail import send_mail
from .models import KYC, WithdrawRequest, DepositRequest
from django.views.decorators.http import require_POST
from django.contrib.auth.hashers import check_password
from django.conf import settings
from django.http import HttpResponse
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO


# Utility function
def generate_account_number():
    return str(random.randint(100000000000, 999999999999))

#KYC success
def kyc_success(request):
    return render(request, 'bank/kyc_success.html')

# Home View
def home(request):
    return render(request, 'bank/home.html')


# Employee login
logger = logging.getLogger(__name__)

def employee_login(request):
    if request.method == 'POST':
        employee_id = request.POST.get('employee_id')
        password = request.POST.get('password')

        try:
            # Check if the employee exists based on EMP_id
            employee = BankEmployee.objects.get(employee_id=employee_id)

            # Directly compare the password (No hashing)
            if employee.password == password:
                # Store the employee's details in the session
                request.session['employee_id'] = employee.employee_id
                request.session['employee_name'] = employee.name
                request.session['employee_role'] = employee.role  # Store role

                # Check the role and redirect accordingly
                if employee.role.lower() == 'kyc_officer':  # Ensure case insensitivity
                    return redirect('employee_dashboard')  # Redirect to KYC officer dashboard
                elif employee.role.lower() == 'cashier':  # Ensure case insensitivity
                    return redirect('cashier_dashboard')  # Redirect to cashier dashboard
                else:
                    messages.error(request, 'Unknown role assigned.')
            else:
                messages.error(request, 'Incorrect password.')

        except BankEmployee.DoesNotExist:
            messages.error(request, 'Employee not found.')

    return render(request, 'employee/login.html')

# Employee dashboard
def employee_dashboard(request):
    if 'employee_id' not in request.session:
        logger.debug("Employee not logged in, redirecting to login.")
        return redirect('employee_login')
    
    # Get employee details from session
    employee_name = request.session.get('employee_name')
    employee_role = request.session.get('employee_role')  # Get the employee role
    
    logger.debug(f"Employee Name: {employee_name}")
    logger.debug(f"Employee Role: {employee_role}")
    
    # Check if the employee is a KYC officer
    if employee_role != 'kyc_officer':
        logger.error("Employee role mismatch! Not a KYC Officer.")
        return redirect('employee_login')  # Redirect to login if not a KYC officer

    # Get customers with pending KYC
    pending_kyc_customers = KYC.objects.filter(verified=False)
    
    # Get pending withdraw and deposit requests
    pending_withdraw_requests = WithdrawRequest.objects.filter(status='Pending')
    pending_deposit_requests = DepositRequest.objects.filter(status='Pending')

    logger.debug(f"Pending KYC Customers: {pending_kyc_customers.count()}")
    logger.debug(f"Pending Withdraw Requests: {pending_withdraw_requests.count()}")
    logger.debug(f"Pending Deposit Requests: {pending_deposit_requests.count()}")

    # Render the employee dashboard with necessary context
    return render(request, 'employee/dashboard.html', {
        'employee_name': employee_name,
        'pending_kyc_customers': pending_kyc_customers,
        'pending_withdraw_requests': pending_withdraw_requests,
        'pending_deposit_requests': pending_deposit_requests,
    })
    
#Employee Logout View
def employee_logout(request):
    request.session.flush()
    return render(request, 'employee/login.html')

# Customer register view
def register_customer(request):
    if request.method == 'POST':
        form = CustomerRegistrationForm(request.POST)
        
        # Debugging: Print form data and check if the form is valid
        print("Form Data:", request.POST)
        print("Form Valid:", form.is_valid())
        
        if form.is_valid():
            customer = form.save(commit=False)
            customer.account_number = generate_account_number()
            
            # Store the password directly (no hashing for now)
            customer.password = form.cleaned_data['password']
            customer.save()

            # Reset the form after successful registration
            form = CustomerRegistrationForm()

            # Redirect to a success page (this can be customized)
            return redirect('registration_success', account_number=customer.account_number)
        else:
            # If the form is not valid, print form errors to debug
            print("Form Errors:", form.errors)
    else:
        form = CustomerRegistrationForm()
    
    return render(request, 'bank/registration.html', {'form': form})

#registration_success
def registration_success(request, account_number):
    return render(request, 'bank/success.html', {'account_number': account_number})


# KYC Submission
def kyc_submission(request, account_number):
    customer = get_object_or_404(Customer, account_number=account_number)

    # Check if KYC already exists for this customer
    if hasattr(customer, 'kyc'):
        messages.info(request, "You have already submitted your KYC.")
        return redirect('kyc_success')

    if request.method == 'POST':
        form = KYCForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                kyc = form.save(commit=False)
                kyc.customer = customer
                kyc.save()
                customer.kyc_verified = True
                customer.save()
                return redirect('kyc_success')
            except IntegrityError:
                messages.error(request, "KYC already submitted.")
                return redirect('kyc_success')
    else:
        form = KYCForm()

    return render(request, 'bank/kyc_form.html', {'form': form, 'customer': customer})

# ATM set_up
def atm_setup(request, account_number):
    # Get the customer object
    customer = get_object_or_404(Customer, account_number=account_number)
    
    # Create ATMCard if it doesn't exist
    atm_card, created = ATMCard.objects.get_or_create(customer=customer)

    # Generate ATM card number if not already assigned
    if not atm_card.card_number:
        atm_card.card_number = "4" + str(customer.id).zfill(15)[-15:]
        atm_card.save()

    if request.method == 'POST':
        # Initialize the form without `instance` since it's a non-model form
        form = ATMSetupForm(request.POST)
        
        if form.is_valid():
            card_number = form.cleaned_data['card_number']
            otp = form.cleaned_data['otp']
            pin = form.cleaned_data['pin']
            
            # Check if the entered card number matches the generated one
            if card_number != atm_card.card_number:
                messages.error(request, "Card number mismatch.")
            elif otp != atm_card.otp:
                messages.error(request, "Invalid OTP.")
            else:
                # Set the ATM PIN and deactivate OTP after successful setup
                atm_card.pin = pin
                atm_card.otp = ""  # Clear OTP after use
                atm_card.is_active = True
                atm_card.save()

                messages.success(request, "ATM PIN set successfully!")
                return redirect('atm_success')  # Redirect after success
    else:
        # Create an empty form
        form = ATMSetupForm()

    return render(request, 'bank/atm_setup.html', {'form': form, 'customer': customer})

# ATM PIN Setup
def set_atm_pin(request, account_number):
    customer = get_object_or_404(Customer, account_number=account_number)
    atm_card, _ = ATMCard.objects.get_or_create(customer=customer)

    if request.method == 'POST':
        pin = request.POST.get('pin')
        confirm_pin = request.POST.get('confirm_pin')

        if pin != confirm_pin:
            messages.error(request, "PINs do not match.")
        elif len(pin) != 6 or not pin.isdigit():
            messages.error(request, "PIN must be a 6-digit number.")
        else:
            atm_card.pin = pin
            atm_card.otp = str(random.randint(100000, 999999))
            atm_card.otp_created_at = timezone.now()
            atm_card.save()
            messages.success(request, f"OTP sent! Please verify to activate your card.")
            return redirect('verify_otp', account_number=account_number)

    return render(request, 'bank/set_atm_pin.html', {'customer': customer})

# OTP Verification
def verify_otp(request, account_number):
    customer = get_object_or_404(Customer, account_number=account_number)
    atm_card = get_object_or_404(ATMCard, customer=customer)

    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        if atm_card.otp and entered_otp == atm_card.otp:
            atm_card.otp = ''
            atm_card.otp_created_at = None
            atm_card.is_active = True
            atm_card.save()
            messages.success(request, "✅ OTP verified successfully! Your ATM card is now active.")
            return redirect('atm_success')
        else:
            messages.error(request, "❌ Invalid OTP. Please try again.")

    return render(request, 'bank/verify_otp.html', {'customer': customer})

# Customer Login
def customer_login(request):
    if request.method == 'POST':
        account_number = request.POST.get('account_number')
        full_name = request.POST.get('full_name')  # Get fullname
        password = request.POST.get('password')  # Get password

        try:
            customer = Customer.objects.get(account_number=account_number)
            if customer.full_name == full_name:  # Validate using fullname
                if customer.password == password:  # Validate password
                    # Password is correct
                    request.session['customer_id'] = customer.id
                    return redirect('customer_dashboard')
                else:
                    messages.error(request, "Incorrect password.")  # Show error for incorrect password
            else:
                messages.error(request, "Incorrect fullname.")  # Show error for incorrect fullname
        except Customer.DoesNotExist:
            messages.error(request, "Account not found.")

    return render(request, 'bank/customer_login.html')

# Customer Dashboard
def customer_dashboard(request):
    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('customer_login')

    # Get customer object
    customer = get_object_or_404(Customer, id=customer_id)

    # Check if KYC is verified before granting access
    if not customer.kyc_verified:
        messages.warning(request, "Your KYC is still pending. You cannot access the dashboard yet.")
        return redirect('kyc_submission', account_number=customer.account_number)

    # Get ATM card details associated with the customer
    atm_card = ATMCard.objects.filter(customer=customer).first()

    # Continue with dashboard logic...
    return render(request, 'bank/customer_dashboard.html', {'customer': customer, 'atm_card': atm_card})

# Customer Logout
def customer_logout(request):
    request.session.flush()
    return redirect('customer_login')

# Verify KYC
def verify_kyc(request, kyc_id):
    kyc = get_object_or_404(KYC, id=kyc_id)

    if request.method == 'POST':
        # 1. Mark KYC as verified
        kyc.verified = True
        kyc.save()

        # 2. Mark Customer as verified
        customer = kyc.customer
        customer.kyc_verified = True
        customer.save()

        # 3. Check if the customer already has an ATM card
        existing_card = ATMCard.objects.filter(customer=customer).first()
        if existing_card:
            messages.success(request, f"KYC for {customer.full_name} has been verified. The customer already has an ATM card.")
        else:
            # 4. Generate unique 16-digit ATM card number
            while True:
                card_number = ''.join([str(random.randint(0, 9)) for _ in range(16)])
                if not ATMCard.objects.filter(card_number=card_number).exists():
                    break

            # 5. Set card validity dates
            valid_from = timezone.now().date()
            valid_thru = valid_from.replace(year=valid_from.year + 5)

            # 6. Create ATMCard (no OTP yet, not verified)
            atm_card = ATMCard.objects.create(
                customer=customer,
                card_number=card_number,
                is_active=True,  # Set as active immediately after creation
                valid_from=valid_from,
                valid_thru=valid_thru,
            )

            # 7. Send email to the customer's email
            subject = "✅ KYC Approved - Your Secure Bank ATM Card Issued"
            message = (
                f"Dear {customer.full_name},\n\n"
                f"Your KYC has been successfully verified by Secure Bank.\n"
                f"We’ve issued your ATM card with the details below:\n\n"
                f"👉 Card Number: {atm_card.card_number}\n"
                f"📅 Valid From: {atm_card.valid_from}\n"
                f"📅 Valid Thru: {atm_card.valid_thru}\n\n"
                f"Next Step: Please log in and complete your ATM PIN setup.\n\n"
                f"Thank you for choosing Secure Bank.\n"
            )
            
            # Send the email to the customer's email address
            send_mail(
                subject, 
                message, 
                settings.EMAIL_HOST_USER,  # The email address defined in your settings.py
                [customer.email],  # Send to the email stored in the customer model
                fail_silently=False
            )

            messages.success(request, f"KYC for {customer.full_name} has been verified and ATM card issued.")

        # Redirect to employee dashboard after the process
        return redirect('employee_dashboard')

    return render(request, 'bank/verify_kyc.html', {'kyc': kyc})

# Download virtual ATM card
def download_virtual_card(request, account_number):
    # Get customer and ATM card details
    customer = get_object_or_404(Customer, account_number=account_number)
    atm_card = get_object_or_404(ATMCard, customer=customer)

    # Create an image object
    card = Image.new('RGB', (640, 400), color=(58, 59, 61))
    draw = ImageDraw.Draw(card)

    # Use a font for text (you can use any font you prefer)
    font = ImageFont.load_default()

    # Add Secure Bank label
    draw.text((220, 50), "Secure Bank", font=font, fill=(255, 255, 255))

    # Add Card number
    draw.text((50, 120), f"Card Number: {atm_card.card_number}", font=font, fill=(255, 255, 255))

    # Add Valid Dates
    draw.text((50, 180), f"Valid From: {atm_card.valid_from}", font=font, fill=(255, 255, 255))
    draw.text((50, 220), f"Valid Thru: {atm_card.valid_thru}", font=font, fill=(255, 255, 255))

    # Add Customer Name (using correct field)
    draw.text((50, 270), f"Customer: {customer.full_name}", font=font, fill=(255, 255, 255))

    # Save image in a memory buffer
    image_stream = BytesIO()
    card.save(image_stream, format='PNG')
    image_stream.seek(0)

    # Return image as response
    response = HttpResponse(image_stream, content_type='image/png')
    response['Content-Disposition'] = f'attachment; filename="virtual_atm_card_{atm_card.card_number}.png"'

    return response


# KYC Rejection Views
def reject_kyc(request, kyc_id):
    kyc = get_object_or_404(KYC, id=kyc_id)

    if request.method == 'POST':
        kyc.verified = False
        kyc.save()
        messages.success(request, f"KYC for {kyc.customer.full_name} has been rejected.")
        return redirect('employee_dashboard')

    return render(request, 'bank/reject_kyc.html', {'kyc': kyc})

#Manager Login View
def manager_login(request):
    if request.method == 'POST':
        manager_id = request.POST.get('manager_id')
        password = request.POST.get('password')
        
        try:
            manager = BankManager.objects.get(manager_id=manager_id)
            if manager.password == password:  # Simple plain-text check
                request.session['manager_id'] = manager.manager_id
                request.session['manager_name'] = manager.name
                return redirect('manager_dashboard')
            else:
                messages.error(request, 'Invalid password.')
        except BankManager.DoesNotExist:
            messages.error(request, 'Manager ID not found.')
    
    return render(request, 'manager/login.html')

# Manager Login View
def manager_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_superuser:
            login(request, user)
            request.session['manager_id'] = user.id
            request.session['manager_name'] = user.username
            return redirect('manager_dashboard')
        else:
            messages.error(request, 'Invalid credentials or not a manager.')

    return render(request, 'manager/login.html')


# Register Employee by manager View
def register_employee(request):
    if 'manager_id' not in request.session:
        return redirect('manager_login')

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        role = request.POST.get('role')  # 👈 NEW

        # Generate unique employee ID
        employee_id = "EMP-" + str(random.randint(100000, 999999))
        while BankEmployee.objects.filter(employee_id=employee_id).exists():
            employee_id = "EMP-" + str(random.randint(100000, 999999))

        # Create the employee with role
        BankEmployee.objects.create(
            name=name,
            employee_id=employee_id,
            email=email,
            password=password,
            role=role  # 👈 NEW
        )

        messages.success(request, f"Employee {name} ({role}) registered successfully with ID: {employee_id}")
        return redirect('register_employee')

    return render(request, 'manager/register_employee.html')


# Manager Dashboard View 1
@login_required
@user_passes_test(lambda u: u.is_superuser)
def manager_dashboard(request):
    return render(request, 'manager/dashboard.html', {
        'manager_name': request.session.get('manager_name')
    })
    
# Mnager Dashboard view 2    
def manager_dashboard(request):
    customer_count = Customer.objects.count()
    employee_count = BankEmployee.objects.count()
    kyc_pending_count = KYC.objects.filter(verified=False).count()
    withdraw_pending_count = WithdrawRequest.objects.filter(status='pending').count()
    deposit_pending_count = DepositRequest.objects.filter(status='pending').count()

    recent_activities = [
        "New Customer Registration",
        "KYC Approval",
        "Recent Withdrawals/Deposits"
    ]

    context = {
        'customer_count': customer_count,
        'employee_count': employee_count,
        'kyc_pending_count': kyc_pending_count,
        'withdraw_pending_count': withdraw_pending_count,
        'deposit_pending_count': deposit_pending_count,
        'recent_activities': recent_activities,
    }

    return render(request, 'manager/dashboard.html', context)

# Manager Logout View
def manager_logout(request):
    logout(request)
    request.session.flush()
    return redirect('manager_login')


#KYC requests view
def kyc_requests(request):
    # Check session for logged-in employee
    if 'employee_id' not in request.session:
        return redirect('employee_login')

    kyc_requests = KYC.objects.filter(verified=False)
    return render(request, 'bank/kyc_requests.html', {'kyc_requests': kyc_requests})

# Cashier dashboard view
def cashier_dashboard(request):
    # Ensure that the user is authenticated by checking the session
    if 'employee_id' not in request.session:
        return redirect('employee_login')  # Redirect to login if not authenticated
    
    # Get employee details from session
    employee_id = request.session.get('employee_id')
    employee_name = request.session.get('employee_name')
    employee_role = request.session.get('employee_role')  # Make sure the role is stored in session

    # Check if the employee is a cashier, otherwise redirect to the login
    if employee_role != 'cashier':
        return redirect('employee_login')  # Redirect to login if not a cashier

    # Fetch pending withdraw and deposit requests
    withdraw_requests = WithdrawRequest.objects.filter(status='pending')  # Use lowercase 'pending'
    deposit_requests = DepositRequest.objects.filter(status='pending')  # Use lowercase 'pending'

    # Debugging logs to ensure data is being passed
    print(f"Withdraw Requests: {withdraw_requests}")
    print(f"Deposit Requests: {deposit_requests}")
    
    # Customer search functionality
    searched_customer = None
    search_not_found = False

    if 'search_account_number' in request.GET:
        account_number = request.GET.get('search_account_number')
        try:
            searched_customer = Customer.objects.get(account_number=account_number)
        except Customer.DoesNotExist:
            search_not_found = True

    # Pass necessary data to the template
    context = {
        'employee_name': employee_name,
        'withdraw_requests': withdraw_requests,
        'deposit_requests': deposit_requests,
        'searched_customer': searched_customer,
        'search_not_found': search_not_found,
        'show_balance_popup': searched_customer is not None,
        'show_notfound_popup': search_not_found,
    }

    return render(request, 'employee/cashier_dashboard.html', context)


# Withdraw request
def withdraw_request(request):
    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('customer_login')  # If not logged in, redirect to login

    customer = get_object_or_404(Customer, id=customer_id)

    if request.method == 'POST':
        form = WithdrawRequestForm(request.POST)
        if form.is_valid():
            withdraw_request = form.save(commit=False)
            withdraw_request.customer = customer
            withdraw_request.save()
            messages.success(request, 'Withdrawal request submitted successfully!')
            return redirect('customer_dashboard')
    else:
        form = WithdrawRequestForm()

    return render(request, 'bank/withdraw_request.html', {'form': form})


# Customer - Deposit Request
def deposit_request(request):
    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('customer_login')  # If not logged in, redirect to login

    customer = get_object_or_404(Customer, id=customer_id)

    if request.method == 'POST':
        form = DepositRequestForm(request.POST)
        if form.is_valid():
            deposit_request = form.save(commit=False)
            deposit_request.customer = customer
            deposit_request.save()
            messages.success(request, 'Deposit request submitted successfully!')
            return redirect('customer_dashboard')
    else:
        form = DepositRequestForm()

    return render(request, 'bank/deposit_request.html', {'form': form})


# Approve Withdraw Request
def approve_withdraw_request(request, request_id):
    try:
        withdraw_request = WithdrawRequest.objects.get(id=request_id)
        
        # Check if customer has sufficient balance
        if withdraw_request.customer.balance >= withdraw_request.amount:
            withdraw_request.status = 'approved'
            withdraw_request.customer.balance -= withdraw_request.amount  # Deduct balance from customer
            withdraw_request.customer.save()
            withdraw_request.save()

            messages.success(request, f"Withdraw request of ₹{withdraw_request.amount} has been approved.")
        else:
            messages.error(request, "Insufficient balance for the withdrawal request.")

    except WithdrawRequest.DoesNotExist:
        messages.error(request, "Withdraw request not found.")
    
    return redirect('cashier_dashboard')  # Redirect back to cashier dashboard after handling the request

# Reject Withdraw Request
def reject_withdraw_request(request, request_id):
    try:
        withdraw_request = WithdrawRequest.objects.get(id=request_id)
        withdraw_request.status = 'rejected'
        withdraw_request.save()

        messages.success(request, "Withdraw request has been rejected.")
    except WithdrawRequest.DoesNotExist:
        messages.error(request, "Withdraw request not found.")
    
    return redirect('cashier_dashboard')

# Approve Deposit Request
def approve_deposit_request(request, request_id):
    try:
        deposit_request = DepositRequest.objects.get(id=request_id)
        
        # Update the customer balance
        deposit_request.status = 'approved'
        deposit_request.customer.balance += deposit_request.amount  # Add deposit amount to customer
        deposit_request.customer.save()
        deposit_request.save()

        messages.success(request, f"Deposit request of ₹{deposit_request.amount} has been approved.")
    except DepositRequest.DoesNotExist:
        messages.error(request, "Deposit request not found.")
    
    return redirect('cashier_dashboard')

# Reject Deposit Request
def reject_deposit_request(request, request_id):
    try:
        deposit_request = DepositRequest.objects.get(id=request_id)
        deposit_request.status = 'rejected'
        deposit_request.save()

        messages.success(request, "Deposit request has been rejected.")
    except DepositRequest.DoesNotExist:
        messages.error(request, "Deposit request not found.")
    
    return redirect('cashier_dashboard')