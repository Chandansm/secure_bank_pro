from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('bank.urls')),  # Include bank URLs first
    path('', lambda request: redirect('home')),  # Root redirects to home
]
